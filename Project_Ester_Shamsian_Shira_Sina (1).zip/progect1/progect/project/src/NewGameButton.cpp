#include "NewGameButton.h"
//-----------------------------------------------------------------------------------
NewGameButton::NewGameButton(const Objects index,  sf::Vector2f location)
	:Button(index,location)
{
}
//-----------------------------------------------------------------------------------
void NewGameButton::handleClick(const sf::Event::MouseButtonEvent& event, sf::RenderWindow& window)
{
}
