#include "Gift.h"

Gift::Gift(const Objects index,  sf::Vector2f location, int width, int hight)
	:StaticObject(index, location, width, hight)
{
}
